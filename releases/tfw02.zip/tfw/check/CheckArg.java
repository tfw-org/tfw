/*
 * The Framework Project
 * Copyright (C) 2005 Anonymous
 * 
 * This library is free software; you can
 * redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your
 * option) any later version.
 * 
 * This library is distributed in the hope that it
 * will be useful, but WITHOUT ANY WARRANTY;
 * witout even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU
 * Lesser General Public License along with this
 * library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA
 */
package tfw.check;

public final class CheckArg
{
	private CheckArg() {}
	
	public static final void isNull(Object object, String objectName)
	{
		if (object == null)
			throw new IllegalArgumentException(
				objectName + " == null not allowed!");
	}
	
	public static final void hasNull(Object[] array, String arrayName)
	{
		for (int i=0 ; i < array.length ; i++)
		{
			if (array[i] == null)
				throw new IllegalArgumentException(
					arrayName + "[" + i + "] == null not allowed!");
		}
	}
	
	public static final void isNotEqual(long left, long right,
		String leftName, String rightName)
	{
		if (left != right)
			throw new IllegalArgumentException(
				leftName + " (=" + left + ") != " +
				rightName + " (=" + right + ") not allowed!");
	}
	
	public static final void isGreaterThan(long left, long right,
			String leftName, String rightName)
	{
		if (left > right)
			throw new IllegalArgumentException(
					leftName + " (=" + left + ") > " +
					rightName + " (=" + right + ") not allowed!");
	}
		
	public static final void isGreaterThanOrEqual(long left, long right,
		String leftName, String rightName)
	{
		if (left >= right)
			throw new IllegalArgumentException(
					leftName + " (=" + left + ") >= " +
					rightName + " (=" + right + ") not allowed!");
	}
	
	public static final void isLessThanConstant(int value, int constant,
			String valueName)
	{
		if (value < constant)
			throw new IllegalArgumentException(
				valueName + " (=" + value + ") < " + constant +
				" not allowed!");
	}

	public static final void isLessThanConstant(long value, long constant,
		String valueName)
	{
		if (value < constant)
			throw new IllegalArgumentException(
				valueName + " (=" + value + ") < " + constant +
				" not allowed!");
	}
}
