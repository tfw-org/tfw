/*
 * The Framework Project
 * Copyright (C) 2005 Anonymous
 * 
 * This library is free software; you can
 * redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your
 * option) any later version.
 * 
 * This library is distributed in the hope that it
 * will be useful, but WITHOUT ANY WARRANTY;
 * witout even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU
 * Lesser General Public License along with this
 * library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA
 */
 package tfw.check;


/**
 * A utility for checking arguements to methods and constructors.

 */
public class CheckArgument
{
    /**
     * Checks the argument for a null value.
     * @param argument the argument to be checked.
     * @param argumentName the name of the argument.
     *
     * @throws IllegalArgumentException if <code>argument == null</code>.
     */
    public static void checkNull(Object argument, String argumentName)
    {
        if (argument == null)
        {
            throw new IllegalArgumentException(argumentName +
                " == null not allowed");
        }
    }

    /**
     * Checks the array argument for zero length.
     * @param argument the argument to be checked.
     * @param argumentName the name of the argument.
     *
     * @throws IllegalArgumentException if <code>argument == null</code>.
     * @throws IllegalArgumentException if <code>argument.length == 0</code>.
     */
    public static void checkEmpty(Object[] argument, String argumentName)
    {
        checkNull(argument, argumentName);

        if (argument.length == 0)
        {
            throw new IllegalArgumentException(argumentName +
                ".length == 0 not allowed");
        }
    }

    /**
     * Checks the array argument for zero length.
     * @param argument the argument to be checked.
     * @param argumentName the name of the argument.
     *
     * @throws IllegalArgumentException if <code>argument == null</code>.
     * @throws IllegalArgumentException if <code>argument[i] == null</code>.
     */
    public static void checkNullElement(Object[] argument, String argumentName)
    {
        checkNull(argument, argumentName);

        for (int i = 0; i < argument.length; i++)
        {
            if (argument[i] == null)
            {
                throw new IllegalArgumentException(argumentName + "[" + i +
                    "]" + "== null not allowed");
            }
        }
    }

	/**
	 * Checks the type of the argument.
	 * @param argument The argument to be checked.
	 * @param argumentName The name of the argument to be checked.
	 * @param type The expected type of the argument.
	 * 
	 * @throws IllegalArgumentException if <code>argument</code> is not 
	 * assignable to <code>type</code>.
	 */
    public static void checkInstanceOf(Object argument, String argumentName,
        Class type)
    {
        checkNull(type, "type");

        if (!(type.isInstance(argument)))
        {
            throw new IllegalArgumentException(argumentName +
                " is not assignable to type '" + type.getName() + "'");
        }
    }
}
