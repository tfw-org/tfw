package tfw.swing2;

import java.awt.Component;

import javax.swing.JPanel;

import tfw.check.CheckArgument;
import tfw.tsm.Branch;
import tfw.tsm.BranchBox;

public class JPanelBB extends JPanel implements BranchBox
{
	private final Branch branch;

	public JPanelBB(String name)
	{
        CheckArgument.checkNull(name, "name");
		branch = new Branch("JPanel["+name+"]");
	}

	public JPanelBB(Branch branch)
	{
        CheckArgument.checkNull(branch, "nbranchame");
		if (branch == null)
			throw new IllegalArgumentException(
				"branch == null not allowed");
		this.branch = branch;
	}

	public void addToBoth(Component component)
	{
		add(component);
		addBranchBox((BranchBox)component);
	}

	public void addToBoth(String name, Component component)
	{
		add(name, component);
		addBranchBox((BranchBox)component);
	}

	public void addToBoth(Component component, Object constraints)
	{
		add(component, constraints);
		addBranchBox((BranchBox)component);
	}

	public void removeFromBoth(Component component)
	{
		remove(component);
		removeBranchBox((BranchBox)component);
	}

	public void removeAllFromBoth(Component component)
	{
		removeAll();
		removeAllBranchBoxes();
	}

	public void addBranchBox(BranchBox branchBox)
	{
		CheckArgument.checkNull(branchBox, "branchBox");

		branch.add(branchBox);
	}

	public void removeBranchBox(BranchBox branchBox)
	{
		branch.remove(branchBox);
	}

	public void removeAllBranchBoxes()
	{
		branch.removeAllChildern();
	}

	public Branch getBranch()
	{
		return (branch);
	}
}
