package tfw.swing2;

import tfw.check.CheckArgument;
import tfw.tsm.Branch;
import tfw.tsm.BranchBox;
import tfw.tsm.Commit;
import tfw.tsm.Converter;
import tfw.tsm.Initiator;
import tfw.tsm.ecd.BooleanECD;
import tfw.tsm.ecd.EventChannelDescription;
import tfw.tsm.ecd.StringECD;
import tfw.tsm.ecd.StatelessTriggerECD;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;


/**
 * An event based text field with modified colorization.
 */
public class JTextFieldModifiableBB extends JTextField implements BranchBox
{
    private final Branch branch;
    private boolean fireDocumentEvent = true;
    private final Color defaultDisabledBackground;
    private final Color defaultEnabledBackground;
    private final Color modifiedBackground = new Color(153, 153, 204);
    private final DocumentListener dListener;

    /**
     * Creates text field based on port descriptions.
     * @param name the name of the text field.
     * @param textPort discription of the text event channel.
     * @param textAdjPort discription of the adjusted text event channel.
     * @param enablePort discription of the text field enable state event
     * channel.
     * @param applyPort the name of the text field apply trigger event
     * channel.
     */
    public JTextFieldModifiableBB(String name, final StringECD textPort,
        final StringECD textAdjPort, final BooleanECD enablePort,
        final StatelessTriggerECD applyECD)
    {
        CheckArgument.checkNull(name, "name");
        CheckArgument.checkNull(textPort, "textPort");
        CheckArgument.checkNull(textAdjPort, "textAdjPort");
        CheckArgument.checkNull(enablePort, "enablePort");
        String fullName = "JTextFieldModifiableNB[" + name + "]";
        branch = new Branch(fullName);

        final Initiator initiator = new Initiator(name,
                new EventChannelDescription[]{ applyECD, textAdjPort });

        branch.add(initiator);
        branch.add(new ForegroundBackgroundHandler(name, textPort, textAdjPort,
                enablePort));
        branch.add(new EnableHandler(name, enablePort));
        branch.add(new TextAdjTriggerable(name, textAdjPort, enablePort));
        branch.add(new TextConverter(name, textPort, textAdjPort));

        dListener = new DocumentListener()
                {
                    public void changedUpdate(DocumentEvent e)
                    {
                        if (fireDocumentEvent)
                        {
                            initiator.set(textAdjPort, getText());
                        }
                    }

                    public void insertUpdate(DocumentEvent e)
                    {
                        changedUpdate(e);
                    }

                    public void removeUpdate(DocumentEvent e)
                    {
                        changedUpdate(e);
                    }
                };

        addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    initiator.trigger(applyECD);
                }
            });

        getDocument().addDocumentListener(dListener);

        setEnabled(true);
        defaultEnabledBackground = getBackground();
        setEnabled(false);
        defaultDisabledBackground = getBackground();
    }

    public void setDocument(Document document)
    {
        if (getDocument() != null)
        {
            getDocument().removeDocumentListener(dListener);
        }

        super.setDocument(document);

        if (getDocument() != null)
        {
            getDocument().addDocumentListener(dListener);
        }
    }

    public Branch getBranch()
    {
        return branch;
    }

    /**
     * Sets the foreground and background state of the text field. Sets the
     * value of the text field if the text event channel is set during the
     * state change cycle.
     */
    private final class ForegroundBackgroundHandler extends Commit
    {
        private final StringECD textName;
        private final StringECD textAdjName;
        private final BooleanECD enableName;

        public ForegroundBackgroundHandler(String name, StringECD textSink,
            StringECD textAdjSink, BooleanECD enableSink)
        {
            super("ForegroundBackgroundHandler[" + name + "]",
                new EventChannelDescription[]{ textSink, textAdjSink, enableSink });
            this.textName = textSink;
            this.textAdjName = textAdjSink;
            this.enableName = enableSink;
        }

        protected void commit()
        {
            String text = (String) get(textName);
            String textAdj = (String) get(textAdjName);

            if (!text.equals(textAdj))
            {
                setBackground(modifiedBackground);
            }
            else if (((Boolean) get(enableName)).booleanValue())
            {
                setBackground(defaultEnabledBackground);
                setForeground(Color.black);
            }
            else
            {
                setBackground(defaultDisabledBackground);
                setForeground(Color.black);
            }
        }
    }

    /**
     * Synchronizes the enabled state of the text field with the enable
     * event channel.
     */
    private final class EnableHandler extends Commit
    {
        private final BooleanECD enableName;

        public EnableHandler(String name, BooleanECD enableSink)
        {
            super("EnableHandler[" + name + "]",
                new EventChannelDescription[]{ enableSink });
            this.enableName = enableSink;
        }

        protected void commit()
        {
            boolean enabled = ((Boolean) get(enableName)).booleanValue();
            setEnabled(enabled);
        }
    }

    /**
     * This TriggeredConverter reacts to changes in the textAdj event channel,
     * setting the text field appropriate.
     */
    private final class TextAdjTriggerable extends Converter
    {
        private final StringECD textAdjName;
        private final BooleanECD enableName;

        public TextAdjTriggerable(String name, StringECD textAdjSink,
            BooleanECD enableSink)
        {
            super("TextAdjTriggerable[" + name + "]",
                new StringECD[]{ textAdjSink },
                new EventChannelDescription[]{ enableSink }, null);
            this.textAdjName = textAdjSink;
            this.enableName = enableSink;
        }

        public void convert()
        {
            fireDocumentEvent = false;

            String text = (String) get(textAdjName);

            if (!text.equals(getText()))
            {
                setText(text);
            }

            fireDocumentEvent = true;
        }
    }

    /**
     * This triggerable reacts to changes in the textAdj event channel,
     * setting the text field appropriate.
     */
    private final class TextConverter extends Converter
    {
        private final StringECD textAdjName;
        private final StringECD textName;

        public TextConverter(String name, StringECD textName,
            StringECD textAdjName)
        {
            super("TextConverter[" + name + "]",
                new EventChannelDescription[]{ textName },
                new EventChannelDescription[]{ textAdjName });
            this.textAdjName = textAdjName;
            this.textName = textName;
        }

        public void convert()
        {
            fireDocumentEvent = false;
            setText((String) get(textName));
            fireDocumentEvent = true;
            set(textAdjName, get(textName));
        }
    }
}
