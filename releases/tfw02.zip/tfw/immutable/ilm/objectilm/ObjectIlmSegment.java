/*
 * The Framework Project
 * Copyright (C) 2005 Anonymous
 * 
 * This library is free software; you can
 * redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your
 * option) any later version.
 * 
 * This library is distributed in the hope that it
 * will be useful, but WITHOUT ANY WARRANTY;
 * witout even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU
 * Lesser General Public License along with this
 * library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA
 */
package tfw.immutable.ilm.objectilm;

import tfw.check.CheckArg;

public final class ObjectIlmSegment
{
    private ObjectIlmSegment() { }

    public static ObjectIlm create(ObjectIlm instance, long rowStart, long columnStart)
    {
		return create(instance, rowStart, columnStart,
			instance.width() - columnStart, instance.height() - rowStart);
    }

    public static ObjectIlm create(ObjectIlm instance, long rowStart,
    	long columnStart, long width, long height)
    {
    	CheckArg.isNull(instance, "instance");
    	CheckArg.isLessThanConstant(rowStart, 0, "rowStart");
    	CheckArg.isLessThanConstant(columnStart, 0, "columnStart");
    	CheckArg.isLessThanConstant(width, 0, "width");
    	CheckArg.isLessThanConstant(height, 0, "height");
    	CheckArg.isGreaterThan((rowStart + height), instance.height(),
    		"rowStart + height", "instance.height()");
    	CheckArg.isGreaterThan((columnStart + width), instance.width(),
    		"columnStart + width", "instance.width()");

		return new MyObjectIlm(instance, rowStart, columnStart, width, height);
    }

    private static class MyObjectIlm extends AbstractObjectIlm
    {
		private final ObjectIlm instance;
		private final long rowStart;
		private final long columnStart;

		MyObjectIlm(ObjectIlm instance, long rowStart, long columnStart,
			long width, long height)
		{
		    super(width, height);
		    
		    this.instance = instance;
		    this.rowStart = rowStart;
		    this.columnStart = columnStart;
		}

		protected void toArrayImpl(Object[][] array, int rowOffset, int columnOffset,
			long rowStart, long columnStart, int width, int height)
		{
			instance.toArray(array, rowOffset, columnOffset, this.rowStart + rowStart,
				this.columnStart + columnStart, width, height);
		}
    }
}
