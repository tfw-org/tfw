package tfw.demo;

import tfw.tsm.ecd.IntegerECD;

/**
 * 
 */
public class RedGreenBlueECD extends IntegerECD {
	public RedGreenBlueECD(String name){
		super(name, 0, 255);
	}

}
