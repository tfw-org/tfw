/*
 * The Framework Project
 * Copyright (C) 2005 Anonymous
 * 
 * This library is free software; you can
 * redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your
 * option) any later version.
 * 
 * This library is distributed in the hope that it
 * will be useful, but WITHOUT ANY WARRANTY;
 * witout even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU
 * Lesser General Public License along with this
 * library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA
 */
package tfw.tsm;


import tfw.check.CheckArgument;
import tfw.tsm.ecd.EventChannelDescription;
import tfw.tsm.ecd.RollbackECD;
import tfw.tsm.ecd.StatelessTriggerECD;

import tfw.value.ValueException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * The base class for event handling leaf components.
 */
abstract class EventHandler extends Leaf
{
    //    private final List initiators;

    /**
     * Creates an event handler with the specified attributes.
     * @param name the name of  the event handler.
     * @param sinkDescriptions the set of sink event channels.
     * @param sourceEventChannels the set of source event channels.
     * @throws IllegalArgumentException if there are no sources or sinks
     * specified.
     */
    EventHandler(String name, EventChannelDescription[] triggeringSinks,
        EventChannelDescription[] nonTriggeringSinks,
        EventChannelDescription[] sources)
    {
        super(name, createSinks(name, triggeringSinks, nonTriggeringSinks),
            createSources(name, sources));

        int portCount = (sources == null) ? 0 : sources.length;

        portCount += ((nonTriggeringSinks == null) ? 0 : nonTriggeringSinks.length);
        portCount += ((triggeringSinks == null) ? 0 : triggeringSinks.length);

        if (portCount == 0)
        {
            throw new IllegalArgumentException(
                "(nonTriggeringSinks.length + nonTriggeringSinks.length" +
                " + triggeringSinks.length)" + " == 0 not allowed");
        }

        Iterator sinks = getSinks().values().iterator();

        while (sinks.hasNext())
        {
            ((EventHandlerSink) sinks.next()).setHandler(this);
        }

        //        String[] initiatorNames = (initiators != null)
        //            ? new String[initiators.length] : new String[0];
        //
        //        for (int i = 0; i < initiatorNames.length; i++)
        //        {
        //            initiatorNames[i] = initiators[i].getEventChannelName();
        //        }
        //
        //        this.initiators = Collections.unmodifiableList(Arrays.asList(
        //                    initiatorNames));
    }

    private static Sink[] createSinks(String name,
        EventChannelDescription[] triggeringSinks,
        EventChannelDescription[] nonTriggeringSinks)
    {
        ArrayList list = new ArrayList();

        if (nonTriggeringSinks != null)
        {
            CheckArgument.checkNullElement(nonTriggeringSinks,
                "nonTriggeringSinks");

            for (int i = 0; i < nonTriggeringSinks.length; i++)
            {
                list.add(new EventHandlerSink(name, nonTriggeringSinks[i], false));
            }
        }

        if (triggeringSinks != null)
        {
            CheckArgument.checkNullElement(triggeringSinks, "triggeringSinks");

            for (int i = 0; i < triggeringSinks.length; i++)
            {
                list.add(new EventHandlerSink(name, triggeringSinks[i], true));
            }
        }

        if (list.size() > 0)
        {
            return (Sink[]) list.toArray(new Sink[list.size()]);
        }
        else
        {
            return null;
        }
    }

    private static Source[] createSources(String name,
        EventChannelDescription[] sources)
    {
        List list = new ArrayList();

        if (sources != null)
        {
            CheckArgument.checkNullElement(sources, "sources");

            StateQueueFactory factory = new DefaultStateQueueFactory();

            for (int i = 0; i < sources.length; i++)
            {
                if (sources[i] instanceof RollbackECD)
                {
                    list.add(new InitiatorSource(name, sources[i],
                            factory.create()));
                }
                else
                {
                    list.add(new ProcessorSource(name, sources[i]));
                }
            }
        }

        return (Source[]) list.toArray(new Source[list.size()]);
    }

    /**
     * Returns the current state for the specified event channel.
     *
     * @param sinkEventChannel the event channel whose state is to be returned.
     * @return the current state for the specified event channel.
     */
    protected final Object get(EventChannelDescription sinkEventChannel)
    {
        CheckArgument.checkNull(sinkEventChannel, "sinkEventChannel");

        if (sinkEventChannel instanceof StatelessTriggerECD)
        {
            throw new IllegalArgumentException("The event channel '" +
                sinkEventChannel.getEventChannelName() +
                "' is stateless. Calling the 'get' method on a stateless event channel is not allowed");
        }

        Sink sink = getSink(sinkEventChannel);

        if (sink == null)
        {
            throw new IllegalArgumentException(sinkEventChannel.getEventChannelName() +
                " not found");
        }

        if (sink.getEventChannel() == null)
        {
            throw new IllegalStateException(sinkEventChannel +
                " is not connected to an event channel");
        }

        return (sink.getEventChannel().getState());
    }

    //
    //    /**
    //     * Returns the current state for the specified event channel.
    //     * @param ecd the event channel whose state is to be returned.
    //     * @return the current state for the specified event channel.
    //     */
    //    protected final Object get(EventChannelDescription ecd)
    //    {
    //        CheckArgument.checkNull(ecd, "ecd");
    //
    //        return get(ecd.getEventChannelName());
    //    }

    /**
     * Returns the state of all of the sink event channels for this
     * component.
     * @return the state of all of the sink event channels for this
     * component.
     */
    protected final StateMap get()
    {
        PortMap map = getSinks();
        StateMap stateMap = new StateMap(map.size());

        for (Iterator itr = map.keySet().iterator(); itr.hasNext();)
        {
            EventChannelDescription sinkEventChannel = (EventChannelDescription) itr.next();

            if (!(sinkEventChannel instanceof StatelessTriggerECD))
            {
                stateMap.put(sinkEventChannel, get(sinkEventChannel));
            }
        }

        return stateMap;
    }

    /**
     * Set the state of the specified event channel in a new transaction.
     * @param initiateECD the event channel.
     * @param state the new state for the event channel.
     */
    final void initiatorSet(RollbackECD initiateECD, Object state)
    {
        CheckArgument.checkNull(initiateECD, "initiateECD");
        CheckArgument.checkNull(state, "state");

        InitiatorSource source = (InitiatorSource) getSource(initiateECD.getEventChannelName());

        try
        {
            source.setState(state);
        }
        catch (ValueException ve)
        {
            throw new IllegalArgumentException(ve.getMessage());
        }

        newTransaction(new InitiatorSource[]{ source });
    }

    final void initiatorSet(EventChannelState[] eventChannelState)
    {
        CheckArgument.checkNull(eventChannelState, "eventChannelState");
        CheckArgument.checkNullElement(eventChannelState, "eventChannelState");

        InitiatorSource[] sources = new InitiatorSource[eventChannelState.length];

        for (int i = 0; i < eventChannelState.length; i++)
        {
            String ecName = eventChannelState[i].getECD().getEventChannelName();
            sources[i] = (InitiatorSource) getSource(ecName);

            if (sources[i] == null)
            {
                throw new IllegalArgumentException("eventChannelState[" + i +
                    "].getECD().getEventChannelName() == " + ecName +
                    " is not a known event channel");
            }

            try
            {
                sources[i].setState(eventChannelState[i].getState());
            }
            catch (ValueException ve)
            {
                throw new IllegalArgumentException(ve.getMessage());
            }
        }

        newTransaction(sources);
    }

    private void newTransaction(InitiatorSource[] sources)
    {
        if (!isRooted())
        {
            throw new IllegalStateException(
                "This component is not connected to a root");
        }

        getTransactionManager().addStateChange(sources);
    }

    static void checkForStatelessTrigger(EventChannelDescription[] ecds,
        String name)
    {
        if (ecds == null)
        {
            return;
        }

        for (int i = 0; i < ecds.length; i++)
        {
            if (ecds[i] instanceof StatelessTriggerECD)
            {
                throw new IllegalArgumentException(name + "[" + i +
                    "] instanceof " + StatelessTriggerECD.class.getName() +
                    " not allowed");
            }
        }
    }

    /**
     * Called when a sink event channels state changes. Must be implemented
     * by sub-classes to receive state change notification.
     * @param eventChannel the event channel who's sate has changed.
     */
    abstract void stateChange(EventChannel eventChannel);

    private static class EventHandlerSink extends Sink
    {
        private EventHandler handler = null;

        EventHandlerSink(String name, EventChannelDescription description,
            boolean isTriggering)
        {
            super(name, description, isTriggering);
        }

        void stateChange()
        {
            Source source = handler.getSource(getEventChannelName());

            if ((source != null) && source.isStateSource())
            {
                return;
            }

            handler.stateChange(EventHandlerSink.this.getEventChannel());
        }

        void setHandler(EventHandler handler)
        {
            this.handler = handler;
        }
    }
}
