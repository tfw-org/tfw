package tfw.swing2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import tfw.check.CheckArgument;
import tfw.tsm.Branch;
import tfw.tsm.BranchBox;
import tfw.tsm.Initiator;
import tfw.tsm.ecd.EventChannelDescription;
import tfw.tsm.ecd.StatelessTriggerECD;


/**
 * A button which sends a trigger event on the event channel
 * specified at construction.
 */
public class JButtonBB extends JButton implements BranchBox
{
    private final Branch branch;

    /**
     * Constructs a button.
     * @param name The name for this button and it's associated {@link Branch}.
     * @param triggerName The name of the event channel to send the  trigger
     * event on.
     * @param enableName the name of the enable event channel for setting the
     * enable state of the button.
     */
    public JButtonBB(String name, final StatelessTriggerECD triggerECD)
    {
        super(name);
        CheckArgument.checkNull(name, "name");
        CheckArgument.checkNull(triggerECD, "triggerECD");

        final Initiator initiator = new Initiator(name,
                new EventChannelDescription[]
                {
                    triggerECD
                });
        addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    initiator.trigger(triggerECD);
                }
            });
        branch = new Branch("JButtonNB[" + name + "]");
        branch.add(initiator);
    }

    public Branch getBranch()
    {
        return branch;
    }
}
