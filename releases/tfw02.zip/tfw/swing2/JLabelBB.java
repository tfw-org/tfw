package tfw.swing2;

import javax.swing.JLabel;

import tfw.check.CheckArgument;
import tfw.tsm.Branch;
import tfw.tsm.BranchBox;
import tfw.tsm.Commit;
import tfw.tsm.ecd.EventChannelDescription;
import tfw.tsm.ecd.StringECD;


/**
 *
 */
public class JLabelBB extends JLabel implements BranchBox
{
    private final Branch branch;

    public JLabelBB(String name, StringECD labelName)
    {
        CheckArgument.checkNull(name, "name");
        CheckArgument.checkNull(labelName, "labelName");
        this.branch = new Branch(name);
        branch.add(new LabelCommit(labelName));
    }

    public Branch getBranch()
    {
        return branch;
    }

    private class LabelCommit extends Commit
    {
        private final StringECD labelECD;

        public LabelCommit(StringECD labelECD)
        {
            super("LabelCommit",
                new EventChannelDescription[]
                {
                    labelECD
                });
            this.labelECD = labelECD;
        }

        protected void commit()
        {
            JLabelBB.this.setText((String) get(labelECD));
        }
    }
}
