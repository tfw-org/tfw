package tfw.swing2;

import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import tfw.check.CheckArgument;
import tfw.tsm.Branch;
import tfw.tsm.BranchBox;
import tfw.tsm.Commit;
import tfw.tsm.Initiator;
import tfw.tsm.ecd.BooleanECD;
import tfw.tsm.ecd.EventChannelDescription;
import tfw.tsm.ecd.StringECD;


public class JTextFieldBB extends JTextField implements BranchBox
{
    private final Branch branch;

    /**
     * Creates a <code>JTextFieldNB</code>.
     *
     * @param name the name for this text field.
     * @param textEventChannelName the name of the text event channel for
     * this text field, which is of type <code>String</code>
     * @param enableECD the description for the enable event channel
     * for this text field, which is of type <code>Boolean</code>.
     */
    public JTextFieldBB(String name, final StringECD textECD,
        BooleanECD enableECD)
    {
        CheckArgument.checkNull(name, "name");
        CheckArgument.checkNull(textECD, "textECD");
        CheckArgument.checkNull(enableECD, "enableECD");
        branch = new Branch("JTextFieldNB[" + name + "]");

        final Initiator initiator = new Initiator(name,
                new EventChannelDescription[]
                {
					textECD
                });

        DocumentListener listener = new DocumentListener()
            {
                public void changedUpdate(DocumentEvent e)
                {
                    initiator.set(textECD, getText());
                }

                public void insertUpdate(DocumentEvent e)
                {
                    changedUpdate(e);
                }

                public void removeUpdate(DocumentEvent e)
                {
                    changedUpdate(e);
                }
            };

        getDocument().addDocumentListener(listener);

        branch.add(initiator);
        branch.add(new JTextFieldNBCommit(
                textECD, enableECD, listener, this));
    }

    public Branch getBranch()
    {
        return (branch);
    }

    private class JTextFieldNBCommit extends Commit
    {
        private final StringECD textName;
        private final BooleanECD enableName;
        private final DocumentListener listener;
        private final JTextFieldBB textField;

        public JTextFieldNBCommit(StringECD textSink,
            BooleanECD enableSink, DocumentListener listener,
            JTextFieldBB textField)
        {
            super("JTextFieldNBCommit",
                new EventChannelDescription[]{ textSink, enableSink });

            this.textName = textSink;
            this.enableName = enableSink;
            this.listener = listener;
            this.textField = textField;
        }

        protected void commit()
        {
            System.out.println(getName() + ".commit()");
            System.out.println("isStateChanged(textName) = " +
                isStateChanged(textName));

            if (isStateChanged(textName))
            {
                textField.getDocument().removeDocumentListener(listener);
                textField.setText((String) get(textName));
                textField.getDocument().addDocumentListener(listener);
            }

            if (isStateChanged(enableName))
            {
                textField.setEnabled(((Boolean) get(enableName)).booleanValue());
            }
        }
    }
}
